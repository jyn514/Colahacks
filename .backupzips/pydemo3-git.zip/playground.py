def main():
  print("Hello world")
  print("Hey there guy")

  x = 234122
  y = 30234
  print("Here's some even realer math: %d + %d = %d" % (x, y, x + y))

if __name__ == "__main__":
  main()
