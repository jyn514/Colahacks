#! /bin/sh
mkdir -p bin build
make
