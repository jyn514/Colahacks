#include <iostream>
#include <cmath>

int main(int argc, char** argv) {
  std::cout << "Hey bud" << std::endl;
  std::cout << "Hey math : " << log10(13120000) << std::endl;
  std::cout << "Bye now" << std::endl;
}
