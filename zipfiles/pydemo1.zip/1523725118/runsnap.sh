python playground.py
