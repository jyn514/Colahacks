def main():
  print("Hello world")
  print("Hey there guy")

if __name__ == "__main__":
  main()
