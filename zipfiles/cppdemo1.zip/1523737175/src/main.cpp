#include <iostream>

int main(int argc, char** argv) {
  std::cout << "Hey bud" << std::endl;
}
